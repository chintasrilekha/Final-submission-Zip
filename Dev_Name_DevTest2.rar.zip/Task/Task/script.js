$(document).on('ready', function() {
    $(".center").slick({
      dots: true,
    //   infinite: true,
      centerMode: true,
      slidesToShow: 1,
      slidesToScroll: 1,
      variableWidth: true,
      centerMode: true,
      arrows: true
    });
  });